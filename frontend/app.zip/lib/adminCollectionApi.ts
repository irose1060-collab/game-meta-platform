import type { AdminCollectionStatus } from "@/types/admin-collection";

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8080";

export async function fetchAdminCollectionStatus(): Promise<AdminCollectionStatus> {
  const response = await fetch(`${API_BASE_URL}/api/admin/collection/status`, {
    method: "GET",
    cache: "no-store",
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`수집 현황 조회 실패: ${response.status} ${text}`);
  }

  return response.json();
}